
#include <stdio.h>

int main() {
    int A = 5, B = 3;
    int result;

    result = A+++B---A;

    printf("Result = %d", result);

    return 0;
}

