
#include <stdio.h>

int main() {
    int A, B, C, D, result;

    printf("Enter A, B, C, D: ");
    scanf("%d %d %d %d", &A, &B, &C, &D);

    if (B == 0) {
        printf("Division by zero is not possible");
        return 0;
    }

    result = A / B * C - B + A * D / 3;

    printf("Result = %d", result);

    return 0;
}

