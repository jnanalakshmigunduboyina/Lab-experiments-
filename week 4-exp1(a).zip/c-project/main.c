
#include <stdio.h>

int main() {
    int A, B, C, D, E, F, G, result;

    scanf("%d %d %d %d %d %d %d",
          &A, &B, &C, &D, &E, &F, &G);

    result = A + B*C + (D*E) + F*G;

    printf("Result = %d", result);

    return 0;
}
