
#include <stdio.h>

int main() {
    int i = 5, J;

    J = (i++) + (++i);

    printf("J = %d\n", J);
    printf("i = %d", i);

    return 0;
}
